from pathlib import Path
import sys, json
root = Path(__file__).resolve().parent
sys.path.insert(0, str(root / '.plot-deps'))
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager
from matplotlib.patches import Patch

font_manager.fontManager.addfont('C:/Windows/Fonts/malgun.ttf')
plt.rcParams.update({'font.family':'Malgun Gothic','axes.unicode_minus':False,'font.size':11,'axes.spines.top':False,'axes.spines.right':False,'figure.facecolor':'white'})
charts = root/'charts'; charts.mkdir(exist_ok=True)
summary=json.loads((root/'summary.json').read_text())
labels={'baseline':'기준 FCFS','no-promotion':'홍보 없음','idle-gated':'강한 홍보 제한','buffer-only':'홍보 우선·상한22','traffic-buffer':'혼잡도별 홍보 우선·낮은 상한','buffer-2':'홍보 우선·버퍼2','buffer-6':'홍보 우선·버퍼6','traffic-reserve':'혼잡도별 홍보 우선·상한없음','nearby-only':'대상 고객 확인만','traffic-cap':'혼잡도별 상한40/60/80','traffic-cooldown':'혼잡도별 홍보 간격'}

public=[r for r in summary if r['phase']=='public']
fig,ax=plt.subplots(figsize=(11,7.5),layout='constrained')
bars=ax.barh([labels[r['strategy']] for r in public],[r['revenue']/10000 for r in public],color=['#566577' if r['strategy']=='baseline' else '#276c9d' if r['strategy']=='traffic-cap' else '#aab8c6' for r in public])
ax.invert_yaxis(); ax.set_xlim(0,65);ax.set_xlabel('경기당 평균 확정 매출 (만원)')
ax.set_title('공개 5개 시드: 기준 55.75만원 → 후보 55.87만원',loc='left',pad=20,fontweight='bold')
for bar,r in zip(bars,public):ax.text(bar.get_width()+.5,bar.get_y()+bar.get_height()/2,f"{r['revenue']:,.0f}원",va='center',fontsize=10)
fig.text(.01,-.025,'각 전략20경기 · 같은 상대/좌석교대/반전 · 20개의 독립 표본이 아님',color='#566577',fontsize=10)
fig.savefig(charts/'01-public-revenue.png',dpi=170,bbox_inches='tight');plt.close(fig)

rows=json.loads((root/'validation.json').read_text())['rows']
seeds=list(dict.fromkeys(r['seed'] for r in rows))
diffs=[]
for seed in seeds:
 a=[r['revenue'] for r in rows if r['seed']==seed and r['strategy']=='baseline']
 b=[r['revenue'] for r in rows if r['seed']==seed and r['strategy']=='traffic-cap']
 diffs.append((sum(b)-sum(a))/4)
fig,ax=plt.subplots(figsize=(11,5.2),layout='constrained')
bars=ax.bar(seeds,diffs,color=['#b65353' if d<0 else '#2e7c74' if d>0 else '#aab8c6' for d in diffs])
ax.axhline(0,color='#26364a',linewidth=.8);ax.set_ylim(-12500,2500)
ax.set_ylabel('후보 - 기준, 평균 확정 매출 (원)');ax.set_xlabel('후보 선택에 쓰지 않은 추가 시드 (각4조건 평균)')
ax.set_title('추가 확인: 평균 1,200원 하락 — 개선이 재현되지 않음',loc='left',pad=20,fontweight='bold')
for bar,d in zip(bars,diffs):ax.text(bar.get_x()+bar.get_width()/2,d-350 if d<0 else d+220,f'{d:+,.0f}',ha='center',va='top' if d<0 else 'bottom',fontsize=10)
fig.savefig(charts/'02-validation-by-seed.png',dpi=170);plt.close(fig)

selected=[next(r for r in public if r['strategy']==n) for n in ['baseline','no-promotion','buffer-2','traffic-cap']]
fig,ax=plt.subplots(figsize=(11,4.6),layout='constrained')
left=[0]*len(selected)
for field,label,color in [('cookTicks','제조','#3d8a77'),('orderTicks','접수','#e3b04d'),('promotionTicks','홍보','#9075bd'),('idleTicks','유휴','#d2d8df')]:
 values=[r[field] for r in selected];ax.barh([labels[r['strategy']] for r in selected],values,left=left,label=label,color=color)
 left=[a+b for a,b in zip(left,values)]
ax.invert_yaxis();ax.set_xlim(0,600);ax.set_xlabel('경기당 평균 직원틱 (직원2명 × 300틱 = 600)')
ax.set_title('홍보를 늘려도, 없애도 매출이 줄어든 사례',loc='left',pad=18,fontweight='bold');ax.legend(ncols=4,loc='lower center',bbox_to_anchor=(.5,-.44),frameon=False)
fig.savefig(charts/'03-worker-allocation.png',dpi=170,bbox_inches='tight');plt.close(fig)

cases=json.loads((root/'replay-analysis.json').read_text())
colors={'COOK':'#3d8a77','TAKE_ORDER':'#e3b04d','PROMOTE':'#9075bd','WAIT':'#d2d8df'}
for case in cases:
 gain=case['label']=='public-gain'; pair=case['pair']
 fig,ax=plt.subplots(figsize=(13,5.3),layout='constrained')
 names=[]
 for v,p in enumerate(pair):
  for worker in range(2):
   y=v*2+worker;names.append(('기준' if v==0 else '후보')+f' 직원{worker+1}')
   frames=[f for f in p['frames'] if f['now']>0]
   start=0;previous=None
   for i,f in enumerate(frames):
    task=f['workers'][worker];key=(task['type'],task.get('orderId'))
    if previous is not None and key!=previous:
     ax.broken_barh([(start,i-start)],(y-.32,.64),facecolors=colors[previous[0]],edgecolor='white',linewidth=.25);start=i
    previous=key
   ax.broken_barh([(start,300-start)],(y-.32,.64),facecolors=colors[previous[0]],edgecolor='white',linewidth=.25)
 for p in pair[0]['phases']:
  ax.axvline(p['tick'],color='#687b92',linewidth=.6,alpha=.5)
  ax.text((p['tick']+p['end'])/2,-.8,{'quiet':'한산','steady':'보통','busy':'혼잡'}[p['trafficLevel']],ha='center',fontsize=10)
 if not gain:ax.axvspan(120,200,color='#b65353',alpha=.07)
 ax.set_yticks(range(4),names);ax.set_ylim(3.6,-1.2);ax.set_xlim(0,300);ax.set_xticks(range(0,301,20));ax.set_xlabel('경기 시간 (틱)')
 title='공개 성공 +8,000원' if gain else '추가 검증 실패 -21,000원'
 ax.set_title(f"{title} · 시드{pair[0]['seed']} / 좌석{pair[0]['seat']} / 반전없음",loc='left',pad=22,fontweight='bold')
 ax.legend(handles=[Patch(color=c,label=l) for t,l,c in [('COOK','제조',colors['COOK']),('TAKE_ORDER','접수',colors['TAKE_ORDER']),('PROMOTE','홍보',colors['PROMOTE']),('WAIT','유휴',colors['WAIT'])]],ncols=4,loc='lower center',bbox_to_anchor=(.5,-.38),frameon=False)
 fn='05-gantt-gain.png' if gain else '04-gantt-loss.png';fig.savefig(charts/fn,dpi=170,bbox_inches='tight');plt.close(fig)
print('Created five charts from recorded game results.')
