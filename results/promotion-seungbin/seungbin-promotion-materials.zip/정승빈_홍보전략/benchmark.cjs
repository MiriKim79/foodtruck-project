const fs = require('node:fs');
const path = require('node:path');
const {spawnSync} = require('node:child_process');
const env = require('./environment.json');
process.env.PATH = env.javaBin + path.delimiter + process.env.PATH;
const {match, saveReplay} = require(path.join(env.repo, 'run.js'));
const {competition, RULE_ID} = require(path.join(env.repo, 'src/competition.js'));
const root = __dirname;

function compile(name) {
  const dest = path.join(env.repo, 'build', name);
  fs.mkdirSync(dest, {recursive:true});
  const source = path.join(root, 'sources', name + '.java');
  const temp = path.join(root, 'compile', name);
  fs.mkdirSync(temp, {recursive:true});
  const java = path.join(temp, 'MyStrategy.java');
  fs.copyFileSync(source, java);
  const result = spawnSync('java', ['-m','jdk.compiler/com.sun.tools.javac.Main','--release','17','-encoding','UTF-8','-d',dest,
    ...['Game','Json','Runner'].map(n=>path.join(env.repo,'java',n+'.java')),java], {encoding:'utf8'});
  if(result.status !== 0) throw Error(result.stderr);
}

async function main() {
  const phase = process.argv[2] || 'public';
  const names = phase === 'public' ? ['baseline','no-promotion','idle-gated','buffer-only','traffic-buffer'] : phase === 'reserve' ? ['buffer-2','buffer-6','traffic-reserve'] : phase === 'gated' ? ['nearby-only','traffic-cap','traffic-cooldown'] : ['baseline','traffic-cap'];
  const seeds = phase !== 'validation' ? ['2026','2027','2028','2029','2030'] : ['3101','3102','3103','3104','3105','3106','3107','3108','3109','3110'];
  const output = path.join(root, phase + '.json');
  const rows = [];
  compile('baseline');
  for(const name of names) {
    compile(name);
    for(const seed of seeds) {
      for(const seat of [0,1]) for(const mirror of [false,true]) {
        const seats = seat === 0 ? [name,'baseline'] : ['baseline',name];
        const sim = await match({seed,seats,mirror,captureHistory:false});
        if(sim.trucks.some(t=>t.status!=='OK')) throw Error(JSON.stringify(sim.trucks.map(t=>({status:t.status,error:t.error}))));
        const t=sim.trucks[seat];
        rows.push({strategy:name,seed,seat,mirror,revenue:t.revenue,served:t.served,unfinished:t.unfinished,refunded:t.refunded,
          promotionTicks:t.metrics.PROMOTE,orderTicks:t.metrics.TAKE_ORDER,cookTicks:t.metrics.COOK,idleTicks:t.metrics.WAIT,
          opponentRevenue:sim.trucks[1-seat].revenue,status:t.status,traffic:competition(seed).phaseEvents});
        fs.writeFileSync(output,JSON.stringify({phase,rule:RULE_ID,seeds,opponent:'frozen original teams/A/MyStrategy.java',rows},null,2));
      }
      console.log(phase,name,seed,Math.round(rows.filter(r=>r.strategy===name&&r.seed===seed).reduce((s,r)=>s+r.revenue,0)/4));
    }
  }
}
main().catch(e=>{console.error(e);process.exitCode=1;});
