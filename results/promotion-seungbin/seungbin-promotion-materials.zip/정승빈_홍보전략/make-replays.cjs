const fs=require('node:fs'), path=require('node:path'), {spawnSync}=require('node:child_process');
const env=require('./environment.json');
process.env.PATH=env.javaBin+path.delimiter+process.env.PATH;
const {match,saveReplay}=require(path.join(env.repo,'run.js'));
const {competition}=require(path.join(env.repo,'src/competition.js'));

async function main(){
 const build=path.join(env.repo,'build','traffic-cap');
 const compileDir=path.join(__dirname,'compile','traffic-cap');
 fs.copyFileSync(path.join(__dirname,'sources','traffic-cap.java'),path.join(compileDir,'MyStrategy.java'));
 let r=spawnSync('java',['-m','jdk.compiler/com.sun.tools.javac.Main','--release','17','-encoding','UTF-8','-d',build,...['Game','Json','Runner'].map(n=>path.join(env.repo,'java',n+'.java')),path.join(compileDir,'MyStrategy.java'),path.join(__dirname,'PromotionCheck.java')],{encoding:'utf8'});
 if(r.status!==0)throw Error(r.stderr);
 r=spawnSync('java',['-cp',build,'PromotionCheck'],{encoding:'utf8'});
 if(r.status!==0)throw Error(r.stderr);
 console.log(r.stdout.trim());fs.writeFileSync(path.join(__dirname,'unit-test.txt'),r.stdout);
 const dir=path.join(__dirname,'replays');fs.mkdirSync(dir,{recursive:true});
 const cases=[];
 for(const [seed,seat,mirror,label] of [['2029',1,false,'public-gain'],['3104',0,false,'validation-loss']]) {
  const pair=[];
  for(const name of ['baseline','traffic-cap']) {
   const seats=seat===0?[name,'baseline']:['baseline',name];
   const sim=await match({seed,mirror,seats,captureHistory:true});
   if(sim.trucks.some(t=>t.status!=='OK'))throw Error('Replay failed');
   saveReplay(sim,path.join(dir,label+'-'+name+'.html'));
   const phases=competition(seed).phaseEvents.map((p,i,all)=>{
    const end=all[i+1]?.tick||300;
    const a=sim.history.find(s=>s.now===p.tick).trucks[seat];
    const b=sim.history.find(s=>s.now===end).trucks[seat];
    return {...p,end,revenue:b.revenue-a.revenue,served:b.served-a.served,
     metrics:Object.fromEntries(['PROMOTE','COOK','TAKE_ORDER','WAIT'].map(k=>[k,b.metrics[k]-a.metrics[k]]))};
   });
   const frames=sim.history.map(s=>({now:s.now,revenue:s.trucks[seat].revenue,workers:s.trucks[seat].workers.map(w=>w.lastWork||{type:'WAIT'})}));
   const t=sim.trucks[seat];
   pair.push({name,seed,seat,mirror,label,revenue:t.revenue,served:t.served,unfinished:t.unfinished,refunded:t.refunded,phases,frames,
    starts:sim.events.filter(e=>e.type==='START'&&e.truckId===seat)});
   console.log(label,name,t.revenue,t.refunded);
  }
  const a=pair[0].frames,b=pair[1].frames;
  const first=b.find((s,i)=>s.workers.some((w,j)=>w.type!==a[i].workers[j].type||w.orderId!==a[i].workers[j].orderId));
  cases.push({label,pair,firstDifferentFrame:first?.now});
 }
 fs.writeFileSync(path.join(__dirname,'replay-analysis.json'),JSON.stringify(cases,null,2));
}
main().catch(e=>{console.error(e);process.exitCode=1});
