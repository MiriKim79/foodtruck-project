import java.util.*;
/** 이 파일의 choose만 수정합니다. 한 번 호출될 때 두 직원의 다음 행동을 반환합니다.
 * 진행 중인 작업은 KEEP. 같은 작업 종류에 두 직원을 동시에 배치할 수 없습니다.
 * 매 경기 새 객체/프로세스에서 시작합니다. 출력은 System.err.println을 쓰세요.
 */
public class MyStrategy {
 public Game.Action[] choose(Game.View view) {
  Game.Action[] plan = new Game.Action[2];
  Set<String> busy = new HashSet<>();
  for(int i=0;i<2;i++) {
   var task=view.workers().get(i).task();
   plan[i]=task==null?Game.Action.waitAction():Game.Action.keep();
   if(task!=null)busy.add(task.type());
  }
  String traffic = String.valueOf(view.raw().get("trafficLevel"));
  int nearby = 0;
  double truckX = view.truckId() == 0 ? 300 : 900;
  for (Game.Customer customer : view.customers()) {
   if (Math.abs(customer.x() - truckX) <= 220 && customer.interest() < 4) nearby++;
  }
  int ready = 0;
  int remaining = 0;
  for (Game.Order order : view.cookQueue()) ready += order.cookTime();
  for (Game.Worker worker : view.workers()) {
   if (worker.task() != null && worker.task().type().equals("COOK")) {
    remaining = Math.max(remaining, worker.task().finish() - view.now());
   }
  }
  boolean canPromote = view.now() + 4 < view.horizon();
  for(int i=0;i<2;i++) {
   if(!plan[i].type().equals("WAIT"))continue;
   if(!view.cookQueue().isEmpty()&&!busy.contains("COOK")) {
    plan[i]=Game.Action.cook(view.cookQueue().get(0).id());busy.add("COOK");
    ready -= view.cookQueue().get(0).cookTime();
    remaining = view.cookQueue().get(0).cookTime();
   } else if(canPromote && !busy.contains("PROMOTE") &&
      (ready >= 2 || remaining >= 3)) {
    plan[i]=Game.Action.promote();busy.add("PROMOTE");
   } else if(!view.orderQueue().isEmpty()&&!busy.contains("TAKE_ORDER")) {
    plan[i]=Game.Action.takeOrder(view.orderQueue().get(0).id());busy.add("TAKE_ORDER");
   } else if(!busy.contains("PROMOTE")&&canPromote) {
    plan[i]=Game.Action.promote();busy.add("PROMOTE");
   }
  }
  return plan;
 }
}
