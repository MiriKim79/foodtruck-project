const path=require('node:path'),fs=require('node:fs');
const {pathToFileURL}=require('node:url');
const {chromium}=require('C:/Users/rlawj/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
(async()=>{
 const browser=await chromium.launch({channel:'chrome',headless:true});
 const checks=[];
 try{
  for(const file of fs.readdirSync(path.join(__dirname,'replays')).filter(n=>n.endsWith('.html'))){
   const page=await browser.newPage({viewport:{width:1440,height:1000}});
   const errors=[];page.on('pageerror',e=>errors.push(e.message));
   await page.goto(pathToFileURL(path.join(__dirname,'replays',file)).href);
   await page.locator('#last').click();
   if(!(await page.locator('#time').innerText()).includes('300'))throw Error('End frame missing');
   if(await page.locator('#chart .bar').count()===0)throw Error('Gantt empty');
   if(errors.length)throw Error(errors.join('\n'));
   if(file==='validation-loss-traffic-cap.html'){
    await page.locator('#gantt').screenshot({path:path.join(__dirname,'charts','06-replay-gantt-capture.png')});
    await page.locator('#settlement').screenshot({path:path.join(__dirname,'charts','07-replay-settlement-capture.png')});
   }
   checks.push({file,endFrame:true,gantt:true,errors});
   await page.close();
  }
 }finally{await browser.close();}
 fs.writeFileSync(path.join(__dirname,'replay-ui-checks.json'),JSON.stringify(checks,null,2));
 console.log('PASS: four offline replays, last frame, populated Gantt and no JavaScript errors.');
})().catch(e=>{console.error(e);process.exitCode=1});
