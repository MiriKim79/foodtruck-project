import java.util.*;

public class PromotionCheck {
    static MyStrategy strategy = new MyStrategy();
    static Game.Customer target = new Game.Customer(1, 10000, 0.5, 0, 0, 300);

    static Game.View view(String level, int workload, int now, List<Game.Worker> workers,
                          List<Game.Order> orders, List<Game.Order> cooking, List<Game.Customer> customers) {
        Map<String,Object> raw = new HashMap<String,Object>();
        if (level != null) raw.put("trafficLevel", level);
        return new Game.View(now,300,0,workload,0,0,workers,orders,cooking,customers,List.of(),raw);
    }
    static List<Game.Worker> idle() {
        return List.of(new Game.Worker(0,null),new Game.Worker(1,null));
    }
    static void expect(Game.View view, String first, String second) {
        Game.Action[] result = strategy.choose(view);
        if(result.length!=2 || !result[0].type().equals(first) || !result[1].type().equals(second)) {
            throw new AssertionError(Arrays.toString(result));
        }
    }
    public static void main(String[] args) {
        for(String level : List.of("quiet","steady","busy")) {
            int limit = level.equals("quiet") ? 40 : level.equals("busy") ? 80 : 60;
            expect(view(level,limit-1,0,idle(),List.of(),List.of(),List.of(target)),"PROMOTE","WAIT");
            expect(view(level,limit,0,idle(),List.of(),List.of(),List.of(target)),"WAIT","WAIT");
        }
        expect(view(null,0,0,idle(),List.of(),List.of(),List.of(target)),"PROMOTE","WAIT");
        expect(view("busy",0,296,idle(),List.of(),List.of(),List.of(target)),"WAIT","WAIT");
        expect(view("busy",0,0,idle(),List.of(),List.of(),List.of()),"WAIT","WAIT");
        Game.Customer far = new Game.Customer(1,10000,0.5,0,0,1000);
        expect(view("busy",0,0,idle(),List.of(),List.of(),List.of(far)),"WAIT","WAIT");
        Game.Customer saturated = new Game.Customer(1,10000,0.5,4,0,300);
        expect(view("busy",0,0,idle(),List.of(),List.of(),List.of(saturated)),"WAIT","WAIT");
        Game.Order cook = new Game.Order(1,4000,2,1,"COOK_QUEUE");
        Game.Order order = new Game.Order(2,4000,2,1,"ORDER_QUEUE");
        expect(view("steady",4,0,idle(),List.of(order),List.of(cook),List.of(target)),"COOK","TAKE_ORDER");
        List<Game.Worker> occupied = List.of(new Game.Worker(0,new Game.Task("PROMOTE",0,3,0)),new Game.Worker(1,null));
        expect(view("steady",0,1,occupied,List.of(),List.of(),List.of(target)),"KEEP","WAIT");
        List<Game.Worker> bothBusy = List.of(new Game.Worker(0,new Game.Task("COOK",0,3,1)),new Game.Worker(1,new Game.Task("TAKE_ORDER",0,2,2)));
        expect(view("steady",0,1,bothBusy,List.of(),List.of(),List.of(target)),"KEEP","KEEP");
        System.out.println("PASS: 14 boundary/priority cases, KEEP, unique task allocation, closing, missing traffic and customer eligibility");
    }
}
